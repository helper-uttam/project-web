# Hotel Website 

This is a Hotel Website with Home, About and Contact Section Made using HTML and CSS.

- USED HTML and CSS
- Responsive Layout 

## https://harshit-chaturvedi.github.io/Hotel-Website-/
